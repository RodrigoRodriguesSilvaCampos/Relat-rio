
package com.mycompany.projeto2;

import java.util.Scanner;


public class CadastroUsuario {
    public static void main(String[] args) {
         Scanner leitorTexto=new Scanner(System.in);
         Scanner leitorNumero=new Scanner(System.in);
        System.out.println("Faça seu Login");
         String nomeDigitado=leitorTexto.nextLine();
         System.out.println("Digite sua senha ");
          String senhaDigitada=leitorTexto.nextLine();
          System.out.println("Quantas vezes voce aceita errar sua senha?");
          Integer Erro= leitorNumero.nextInt();
          String frase=String.format("Seu login é %s e sua senha é %s. Você tem"
                  + " %d tentativas antes de ser bloqueado", nomeDigitado,
                  senhaDigitada,Erro);
          System.out.println(frase);
    }
}
