

package com.mycompany.projeto1;

import java.util.Scanner;


public class Exercícos {
    public static void main(String[] args) {
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Quantos filhos de 0 a 3 anos voce possui?");
        Integer idadeDigitada1= leitorNúmero.nextInt();
        
        System.out.println("Quantos filhos de 4 a 16 anos voce possui?");
        Integer idadeDigitada2= leitorNúmero.nextInt();
        
        System.out.println("Quantos filhos de 17 a 18 anos voce possui?");
        Integer idadeDigitada3= leitorNúmero.nextInt();
        
        Integer somaFilhos=idadeDigitada1 + idadeDigitada2 +idadeDigitada3;
        Double soma=idadeDigitada1 * 25.12;
        Double soma2=idadeDigitada2 * 15.88;
        Double soma3=idadeDigitada3 * 12.44;
        Double resultadoSoma= soma + soma2 +soma3;
        String frase=String.format("Você tem um total de %d filhos e vai receber"
                + " R$%.2f de bolsa",
                somaFilhos,resultadoSoma);
        System.out.println(frase);
    }
    
}
