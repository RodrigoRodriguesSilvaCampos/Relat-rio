
package com.mycompany.projeto6;

import java.util.Scanner;


public class Exercício6 {
    public static void main(String[] args) {
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Fale seu sálario bruto");
         Double salarioBruto= leitorNúmero.nextDouble();
        Double INSS=salarioBruto * 0.1;
        Double IR=salarioBruto * 0.2;
        System.out.println("Fale  valor desua condução de casa "
                + "para o trabalho (ida)");
        Double valorVT=leitorNúmero.nextDouble();
        Double contaVT=valorVT * 2 *22;
        Double descontos=INSS + IR + contaVT;
        Double salarioLiquido=salarioBruto - INSS - IR -contaVT;
        String frase=String.format("Seu salário bruto é R$%.2f, tem um total de R$%.2f "
                + "em descontos e receberá um líquido de R$%.2f", salarioBruto,descontos,
                salarioLiquido);
        System.out.println(frase);
                
        
         
    }
}
