
package com.mycompany.projeto5;

import java.util.Scanner;


public class Calculadora {
    public static void main(String[] args) {
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Digite um número");
        Double primNum=leitorNúmero.nextDouble();
        System.out.println("Digite outro número");
        Double secNum=leitorNúmero.nextDouble();
        Double somaNums=primNum + secNum;
        System.out.println("O valor da soma é: " + somaNums);
        Double subtNums=primNum - secNum;
        System.out.println("O valor da subtração é: " + subtNums);
        Double multiplicNums=primNum * secNum;
        System.out.println("O valor da multiplicação é: " + multiplicNums);
        Double divisaoNums=primNum / secNum;
        String frase=String.format("O resultado da divisão é:%.1f", divisaoNums);
        System.out.println(frase);
        
        
    }
}
