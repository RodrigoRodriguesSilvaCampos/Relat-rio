
package com.mycompany.projeto3;

import java.util.Scanner;


public class Exercício3 {
    public static void main(String[] args) {
        Scanner leitorTexto=new Scanner(System.in);
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Quanto tempo você passa aquecendo?");
        Integer tempoAq= leitorNúmero.nextInt();
        System.out.println("Quanto tempo você fez ex. aeróbicos?");
         Integer tempoExa= leitorNúmero.nextInt();
         System.out.println("Quanto tempo você faz musculação?");
         Integer tempoMusc= leitorNúmero.nextInt();
         
         Integer somaAq=12 * tempoAq;
         Integer somaExa=20 * tempoExa;
         Integer somaMusc=25 * tempoMusc;
         Integer somaCalorias= somaAq + somaExa +somaMusc;
         Integer somaTotal=tempoAq + tempoExa + tempoMusc;
         
         String frase=String.format("Olá, Jorge. Você fez um total de "
                 + "%d minutos de exercícios e perdeu cerca de %d calorias", somaTotal,somaCalorias);
         System.out.println(frase);
    }
}
