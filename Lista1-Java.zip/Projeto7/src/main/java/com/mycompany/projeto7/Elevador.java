
package com.mycompany.projeto7;

import java.util.Scanner;


public class Elevador {
    public static void main(String[] args) {
         Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Fale o limite do peso do elevador");
        Double pesoLimite=leitorNúmero.nextDouble();
        System.out.println("Fale o limite de pessoas do elevador");
        Integer pessoasLimite=leitorNúmero.nextInt();
        System.out.println("Fale o peso da primeira pessoa que entrou no elevador");
        Double pesoPrimPessoa=leitorNúmero.nextDouble();
        System.out.println("Fale o peso da segunda pessoa que entrou no elevador");
        Double pesoSecPessoa=leitorNúmero.nextDouble();
        System.out.println("Fale o peso da terceira pessoa que entrou no elevador");
        Double pesoTercPessoa=leitorNúmero.nextDouble();
        
        Double somaPeso=pesoPrimPessoa + pesoSecPessoa + pesoTercPessoa;
        
        String frase = String.format("Entraram 3 pessoas no elevador, no qual cabem %d "
                + "pessoas.\n" +
"O peso total no elevador é de %.2f, sendo que ele suporta %.2f", pessoasLimite,
somaPeso,pesoLimite);
        System.out.println(frase);
        
    }
}
