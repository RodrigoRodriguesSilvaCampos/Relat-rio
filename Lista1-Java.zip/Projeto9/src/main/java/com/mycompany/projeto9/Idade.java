
package com.mycompany.projeto9;

import java.util.Scanner;

public class Idade {
    public static void main(String[] args) {
        Scanner leitorTexto=new Scanner(System.in);
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Digite seu nome");
         String nomeDigitado=leitorTexto.nextLine();
         System.out.println("Olá " + nomeDigitado + "Qual o ano de seu nascimento?" );
         Integer dataNasc=leitorNúmero.nextInt();
         Integer idade2030=2030-dataNasc;
         System.out.println("Em 2030 voce terá: " + idade2030);
    }
}
