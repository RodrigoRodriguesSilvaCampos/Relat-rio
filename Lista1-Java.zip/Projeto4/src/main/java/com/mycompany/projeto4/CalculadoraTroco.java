
package com.mycompany.projeto4;

import java.util.Scanner;


public class CalculadoraTroco {
    public static void main(String[] args) {
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Fale o valor do produto");
        Double valorProduto= leitorNúmero.nextDouble();
        System.out.println("Fale a quantidade vendida");
        Integer quantProd= leitorNúmero.nextInt();
        System.out.println("Fale o valor pago pelo cliente");
        Double valorPago= leitorNúmero.nextDouble();
        
        Double contas=valorProduto * quantProd - valorPago;
        Double troco=contas * (-1);
        
        String frase=String.format("Seu troco será de R$ %.2f", troco);
        System.out.println(frase);
        
        
    }
}
