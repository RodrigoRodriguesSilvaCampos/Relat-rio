
package com.mycompany.projeto8;

import java.util.Scanner;


public class CalculoMedia {
    public static void main(String[] args) {
        Scanner leitorTexto=new Scanner(System.in);
        Scanner leitorNúmero=new Scanner(System.in);
        System.out.println("Escreva seu Nome");
        String name=leitorTexto.nextLine();
        System.out.println("Escreva sua primeira nota");
        Double primNota=leitorNúmero.nextDouble();
        System.out.println("Escreva sua segunda nota");
        Double secNota=leitorNúmero.nextDouble();
        Double média=(primNota + secNota)/2;
        String frase=String.format("Olá, %s. Sua média foi de %.1f ", name,média);
        System.out.println(frase);
    }
}
